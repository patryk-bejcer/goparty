/* eslint-disable no-unused-vars */
export default () => {
  const consts = {
    appURL: process.env.MIX_APP_URL,
  };
};
