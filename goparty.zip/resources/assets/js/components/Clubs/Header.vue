<template>
  <div>
    <search-clubs />
    <div class="container">
      <!--<router-view></router-view>-->
    </div>
  </div>
</template>

<style>
    #clubs-list {
        min-height: 250px;
    }
</style>
