<h3>Welcome to Scotch Queue Team</h3>

<p>This is the most patient team in the Scotch community because we like to wait for our turn</p>

<p>This made our friends love us because we always give them time to do other simple tasks before
    coming back to do ours</p>