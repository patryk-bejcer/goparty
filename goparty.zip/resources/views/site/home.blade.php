@extends('layouts/app')

@section('content')

    <section id="home-page">

        <div class="container">

            <clubs-nearest>
            </clubs-nearest>

            <events-nearest-location>
            </events-nearest-location>

        </div>

    </section>

@endsection