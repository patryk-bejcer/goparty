
    </div>

    @if(isset($flash))
        <flash message="{{$flash}}"></flash>
    @endif

    <div class="mask">

        <div class="top-bar-bg mb-4">

        </div>

    </div>

    <div class="container">